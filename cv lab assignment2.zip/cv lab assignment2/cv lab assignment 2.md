# Landmark Recognition Using SIFT (Lab Assignment)
Run the cells **top to bottom** (Runtime > Run all). Everything is automatic: images are downloaded, the database is built, and all 6 tests run with results shown below.

## 0. Setup

**Output:**

```text
OpenCV 4.14.0
```

## 1. Helper script: download landmark images (Task 1)

**Output:**

```text
Writing download_images.py
```

## 2. Main program: SIFT extraction, matching, RANSAC localization, evaluation (Tasks 2-6)

**Output:**

```text
Writing landmark_sift.py
```

## 3. Task 1: Download images & build the database
After it finishes, check the preview below and delete any wrong photos from `landmark_database/` (left sidebar folder icon), then continue.

**Output:**

```text
Eiffel Tower:
  saved 6 reference + 1 test image(s)
Taj Mahal:
  saved 6 reference + 1 test image(s)
Great Wall of China:
  saved 6 reference + 1 test image(s)
Statue of Liberty:
  saved 6 reference + 1 test image(s)
Colosseum Rome:
  saved 6 reference + 1 test image(s)
Unknown landmark:

Done. Next:
  python landmark_sift.py build
  python landmark_sift.py evaluate --base test_images/Eiffel_Tower.jpg --expected Eiffel_Tower --unknown test_images/unknown.jpg
TIP: open the folders and delete any wrong/irrelevant photos before running build.
```

![output 1](md_images/cell09_1.png)

## 4. Task 2: SIFT feature extraction

**Output:**

```text
======================================================================
Task 1-2: Building SIFT feature database
======================================================================
  Colosseum              images:  6   keypoints: 17145
  Eiffel Tower           images:  6   keypoints: 11839
  Great Wall of China    images:  6   keypoints: 18003
  Statue of Liberty      images:  6   keypoints: 7757
  Taj Mahal              images:  6   keypoints: 13505

Saved descriptors + labels -> /content/output/sift_features.pkl
```

![output 2](md_images/cell12_2.png)

## 5. Tasks 3-5: Query one image (keypoints, matches, localization)

**Output:**

```text
----------------------------------------------------------------------
Query: test_images/Eiffel_Tower.jpg
  Keypoints detected : 3000
  Ranking (reliable matches per landmark):
    1. Taj Mahal              20
    2. Colosseum              18
    3. Statue of Liberty      18
    4. Eiffel Tower           17
    5. Great Wall of China    17
  Reliable matches   : 20
  RANSAC inliers     : 5
  Decision           : Rejected  -> Unknown / rejected
  Reason             : Projected polygon is not convex (unreliable transformation)
  Processing time    : 5.512 s
Result figure saved -> /content/output/screenshots/query_Eiffel_Tower.png
```

![output 3](md_images/cell14_3.png)

## 6. Task 6: Performance evaluation (original, rotated, resized, dark, viewpoint, unknown)

**Output:**

```text
======================================================================
Task 6: Performance evaluation
======================================================================
----------------------------------------------------------------------
Query: Original
  Keypoints detected : 3000
  Ranking (reliable matches per landmark):
    1. Taj Mahal              20
    2. Colosseum              18
    3. Statue of Liberty      18
    4. Eiffel Tower           17
    5. Great Wall of China    17
  Reliable matches   : 20
  RANSAC inliers     : 5
  Decision           : Rejected  -> Unknown / rejected
  Reason             : Projected polygon is not convex (unreliable transformation)
  Processing time    : 5.527 s
----------------------------------------------------------------------
Query: Rotated (45 deg)
  Keypoints detected : 3000
  Ranking (reliable matches per landmark):
    1. Statue of Liberty      46
    2. Eiffel Tower           27
    3. Colosseum              24
    4. Taj Mahal              24
    5. Great Wall of China    15
  Reliable matches   : 46
  RANSAC inliers     : 7
  Decision           : Rejected  -> Unknown / rejected
  Reason             : Projected polygon is not convex (unreliable transformation)
  Processing time    : 5.560 s
----------------------------------------------------------------------
Query: Resized (50%)
  Keypoints detected : 3000
  Ranking (reliable matches per landmark):
    1. Taj Mahal              20
    2. Statue of Liberty      19
    3. Eiffel Tower           18
    4. Great Wall of China    15
    5. Colosseum              13
  Reliable matches   : 20
  RANSAC inliers     : 5
  Decision           : Rejected  -> Unknown / rejected
  Reason             : Projected polygon is not convex (unreliable transformation)
  Processing time    : 5.507 s
----------------------------------------------------------------------
Query: Reduced brightness
  Keypoints detected : 3000
  Ranking (reliable matches per landmark):
    1. Taj Mahal              20
    2. Statue of Liberty      19
    3. Colosseum              17
    4. Great Wall of China    16
    5. Eiffel Tower           15
  Reliable matches   : 20
  RANSAC inliers     : 5
  Decision           : Rejected  -> Unknown / rejected
  Reason             : Projected polygon is not convex (unreliable transformation)
  Processing time    : 5.500 s
----------------------------------------------------------------------
Query: Different viewpoint (perspective warp)
  Keypoints detected : 3000
  Ranking (reliable matches per landmark):
    1. Statue of Liberty      33
    2. Colosseum              24
    3. Taj Mahal              24
    4. Great Wall of China    22
    5. Eiffel Tower           21
  Reliable matches   : 33
  RANSAC inliers     : 7
  Decision           : Rejected  -> Unknown / rejected
  Reason             : Projected polygon is not convex (unreliable transformation)
  Processing time    : 5.469 s
----------------------------------------------------------------------
Query: Unknown landmark (not in DB)
  Keypoints detected : 3000
  Ranking (reliable matches per landmark):
    1. Statue of Liberty      24
    2. Taj Mahal              18
    3. Colosseum              16
    4. Great Wall of China    15
    5. Eiffel Tower           11
  Reliable matches   : 24
  RANSAC inliers     : 2
  Decision           : Rejected  -> Unknown / rejected
  Reason             : Projected polygon is not convex (unreliable transformation)
  Processing time    : 5.250 s

| Test | Predicted | Keypoints | Reliable matches | RANSAC inliers | Decision | Correct | Time (s) |
|---|---|---|---|---|---|---|---|
| Original | Unknown (rejected) | 3000 | 20 | 5 | Rejected | No | 5.527 |
| Rotated (45 deg) | Unknown (rejected) | 3000 | 46 | 7 | Rejected | No | 5.560 |
| Resized (50%) | Unknown (rejected) | 3000 | 20 | 5 | Rejected | No | 5.507 |
| Reduced brightness | Unknown (rejected) | 3000 | 20 | 5 | Rejected | No | 5.500 |
| Different viewpoint (perspective warp) | Unknown (rejected) | 3000 | 33 | 7 | Rejected | No | 5.469 |
| Unknown landmark (not in DB) | Unknown (rejected) | 3000 | 24 | 2 | Rejected | Yes | 5.250 |

Saved: /content/output/results_table.csv, results_table.md, screenshots/
```

```text
                                     Test           Predicted  Keypoints  \
0                                Original  Unknown (rejected)       3000   
1                        Rotated (45 deg)  Unknown (rejected)       3000   
2                           Resized (50%)  Unknown (rejected)       3000   
3                      Reduced brightness  Unknown (rejected)       3000   
4  Different viewpoint (perspective warp)  Unknown (rejected)       3000   
5            Unknown landmark (not in DB)  Unknown (rejected)       3000   

   Reliable matches  RANSAC inliers  Decision Correct  Time (s)  
0                20               5  Rejected      No     5.527  
1                46               7  Rejected      No     5.560  
2                20               5  Rejected      No     5.507  
3                20               5  Rejected      No     5.500  
4                33               7  Rejected      No     5.469  
5                24               2  Rejected     Yes     5.250
```

![output 4](md_images/cell17_4.png)

![output 5](md_images/cell17_5.png)

![output 6](md_images/cell17_6.png)

![output 7](md_images/cell17_7.png)

![output 8](md_images/cell17_8.png)

![output 9](md_images/cell17_9.png)

## 7. (Optional) Evaluate other landmarks
Change `--base` and `--expected`, e.g. `test_images/Taj_Mahal.jpg` / `Taj_Mahal`.

**Output:**

```text
[ERROR] Feature database not found. Run:  python landmark_sift.py build
```

## 8. Discussion
**Performance.** SIFT keypoints are scale-space extrema with orientation assignment and normalised 128-D descriptors, so recognition is robust to scale, rotation and illumination changes. *(State how many of the 6 tests were correct and typical processing time from the table above.)*

**Rejection.** The unknown landmark can produce many raw matches but few RANSAC inliers, so geometric verification rejects it; match count alone is unreliable.

**Limitations.** Large viewpoint changes, occlusion, very dark images (few keypoints), repetitive structures (Colosseum arches, Great Wall) causing false matches, low-texture landmarks, weather/season changes, and slow brute-force matching on large databases.

**Improvements.** FLANN matching, more reference views, CLAHE for dark images, ORB/AKAZE comparison, learned deep features.

## 9. Download everything for submission

