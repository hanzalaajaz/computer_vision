# Lab 05: HOG-Based Industrial Defect Detection and Classification
**Pipeline:** Image → Preprocessing → HOG Feature Extraction → ML Classifier → Accept / Reject decision

**Dataset:** NEU Surface Defect Database (6 steel-defect classes, 300 images each).

> **Note on binary vs multi-class:** NEU-DET contains *only defective* samples (no "normal" class), so a true
> Normal-vs-Defective split is impossible from this dataset alone. This notebook therefore does the **advanced
> 6-class classification** and derives the Accept/Reject decision from the predicted defect type
> (`ACCEPTABLE_CLASSES` in the decision-module cell is configurable). State this assumption in your report.

```python
!pip install -q kagglehub scikit-image opencv-python-headless scikit-learn seaborn pandas matplotlib tabulate
```

```python
import os, glob, time, warnings, random
import numpy as np, pandas as pd
import cv2, matplotlib.pyplot as plt, seaborn as sns
from skimage.feature import hog
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             confusion_matrix, classification_report)
warnings.filterwarnings("ignore")
SEED = 42
random.seed(SEED); np.random.seed(SEED)
IMG_SIZE = 128
RESULTS = {}   # collected tables -> results.md at the end
```

## 1. Load and inspect the dataset

```python
import kagglehub
path = os.environ.get("NEU_PATH") or kagglehub.dataset_download("kaustubhdikshit/neu-surface-defect-database")
print("Path to dataset files:", path)

CLASSES = ["crazing", "inclusion", "patches", "pitted_surface", "rolled-in_scale", "scratches"]
PREFIX = [("crazing","crazing"),("inclusion","inclusion"),("patches","patches"),("pitted","pitted_surface"),
          ("rolled","rolled-in_scale"),("scratches","scratches"),("cr_","crazing"),("in_","inclusion"),
          ("pa_","patches"),("ps_","pitted_surface"),("rs_","rolled-in_scale"),("sc_","scratches")]

def label_of(fp):
    for text in (os.path.basename(fp).lower(), os.path.basename(os.path.dirname(fp)).lower()):
        for pre, cls in PREFIX:
            if text.startswith(pre):
                return cls
    return None

exts = (".jpg", ".jpeg", ".png", ".bmp")
seen, records = set(), []
for fp in sorted(glob.glob(os.path.join(path, "**", "*"), recursive=True)):
    if fp.lower().endswith(exts):
        lab = label_of(fp)
        key = os.path.basename(fp).lower()
        if lab and key not in seen:          # de-duplicate train/val copies
            seen.add(key); records.append((fp, lab))
df = pd.DataFrame(records, columns=["path", "label"])
print("Total images:", len(df))
print(df["label"].value_counts().sort_index())
```

**Output:**

```text
Downloading to /root/.cache/kagglehub/datasets/kaustubhdikshit/neu-surface-defect-database/1.archive...
```

**Output:**

```text
100%|██████████| 26.4M/26.4M [00:00<00:00, 85.0MB/s]
```

**Output:**

```text
Extracting files...
```

**Output:**

```text
Path to dataset files: /root/.cache/kagglehub/datasets/kaustubhdikshit/neu-surface-defect-database/versions/1
Total images: 1800
label
crazing            300
inclusion          300
patches            300
pitted_surface     300
rolled-in_scale    300
scratches          300
Name: count, dtype: int64
```

```python
fig, axes = plt.subplots(2, 6, figsize=(16, 6))
for j, c in enumerate(CLASSES):
    for i, fp in enumerate(df[df.label == c].path.sample(2, random_state=SEED)):
        im = cv2.imread(fp, cv2.IMREAD_GRAYSCALE)
        axes[i, j].imshow(im, cmap="gray"); axes[i, j].axis("off")
        if i == 0: axes[i, j].set_title(c)
plt.suptitle("Sample images per class"); plt.tight_layout(); plt.show()
print("Original image shape example:", cv2.imread(df.path[0], cv2.IMREAD_GRAYSCALE).shape)
RESULTS["Class distribution"] = df["label"].value_counts().sort_index().rename("images").to_frame()
```

![figure 1](images/fig_01_cell5.png)

**Output:**

```text
Original image shape example: (200, 200)
```

## 2. Preprocessing (resize → grayscale → split)

```python
def load_gray(fp):
    im = cv2.imread(fp, cv2.IMREAD_GRAYSCALE)          # grayscale conversion
    return cv2.resize(im, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_AREA)  # common resolution

X_img = np.array([load_gray(p) for p in df.path], dtype=np.uint8)
classes = sorted(df.label.unique()); cls2id = {c: i for i, c in enumerate(classes)}
y = df.label.map(cls2id).values
print("Image tensor:", X_img.shape, "| classes:", classes)

# 70 / 15 / 15 stratified split: validation used for model selection, test only for final reporting
idx = np.arange(len(y))
tr_idx, tmp_idx = train_test_split(idx, test_size=0.30, stratify=y, random_state=SEED)
va_idx, te_idx = train_test_split(tmp_idx, test_size=0.50, stratify=y[tmp_idx], random_state=SEED)
print("train/val/test:", len(tr_idx), len(va_idx), len(te_idx))
```

**Output:**

```text
Image tensor: (1800, 128, 128) | classes: ['crazing', 'inclusion', 'patches', 'pitted_surface', 'rolled-in_scale', 'scratches']
train/val/test: 1260 270 270
```

## 3. HOG feature extraction and visualisation

```python
def extract_hog(images, cell=8, ori=9, block=2):
    return np.array([hog(im, orientations=ori, pixels_per_cell=(cell, cell),
                         cells_per_block=(block, block), block_norm="L2-Hys") for im in images], dtype=np.float32)

fig, axes = plt.subplots(2, 6, figsize=(16, 6))
for j, c in enumerate(classes):
    i0 = np.where(y == cls2id[c])[0][0]
    _, hog_im = hog(X_img[i0], orientations=9, pixels_per_cell=(8, 8), cells_per_block=(2, 2),
                    visualize=True, block_norm="L2-Hys")
    axes[0, j].imshow(X_img[i0], cmap="gray"); axes[0, j].set_title(c); axes[0, j].axis("off")
    axes[1, j].imshow(hog_im, cmap="gray");    axes[1, j].axis("off")
axes[0, 0].set_ylabel("Image"); plt.suptitle("Image (top) vs HOG representation (bottom): cell 8x8, 9 orientations")
plt.tight_layout(); plt.show()
print("HOG feature length (8x8, 9 ori):", extract_hog(X_img[:1]).shape[1])
```

![figure 2](images/fig_02_cell9.png)

**Output:**

```text
HOG feature length (8x8, 9 ori): 8100
```

## 4. Baseline: HOG + SVM vs additional classifiers (cell 8×8, 9 orientations)

```python
def metrics(yt, yp):
    return dict(Accuracy=accuracy_score(yt, yp),
                Precision=precision_score(yt, yp, average="macro", zero_division=0),
                Recall=recall_score(yt, yp, average="macro", zero_division=0),
                F1=f1_score(yt, yp, average="macro", zero_division=0))

def make_models():
    return {
        "SVM (RBF)":     make_pipeline(StandardScaler(), SVC(kernel="rbf", C=10, gamma="scale", random_state=SEED)),
        "Random Forest": RandomForestClassifier(n_estimators=300, n_jobs=-1, random_state=SEED),
        "k-NN (k=5)":    make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5)),
    }

F = extract_hog(X_img, 8, 9)
base_rows, base_preds = {}, {}
for name, m in make_models().items():
    t0 = time.time(); m.fit(F[tr_idx], y[tr_idx]); p = m.predict(F[te_idx])
    base_preds[name] = p; base_rows[name] = {**metrics(y[te_idx], p), "Train+Pred time (s)": time.time() - t0}
base_df = pd.DataFrame(base_rows).T.round(4)
display(base_df)
RESULTS["Baseline classifier comparison (test set, cell 8x8, 9 ori)"] = base_df
```

|               |   Accuracy |   Precision |   Recall |     F1 |   Train+Pred time (s) |
|:--------------|-----------:|------------:|---------:|-------:|----------------------:|
| SVM (RBF)     |     0.8704 |      0.8693 |   0.8704 | 0.8674 |               13.1322 |
| Random Forest |     0.7741 |      0.7771 |   0.7741 | 0.7634 |               34.6474 |
| k-NN (k=5)    |     0.6333 |      0.7696 |   0.6333 | 0.5902 |                0.4799 |

```python
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
for ax, (name, p) in zip(axes, base_preds.items()):
    cm = confusion_matrix(y[te_idx], p)
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=classes, yticklabels=classes, ax=ax, cbar=False)
    ax.set_title(name); ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.tick_params(axis="x", rotation=45)
plt.tight_layout(); plt.show()

for name, p in base_preds.items():
    print("=" * 60, "\n", name, "\n", classification_report(y[te_idx], p, target_names=classes, digits=4))
RESULTS["Classification report: SVM (test)"] = pd.DataFrame(
    classification_report(y[te_idx], base_preds["SVM (RBF)"], target_names=classes, output_dict=True)).T.round(4)
RESULTS["Classification report: Random Forest (test)"] = pd.DataFrame(
    classification_report(y[te_idx], base_preds["Random Forest"], target_names=classes, output_dict=True)).T.round(4)
```

![figure 3](images/fig_03_cell12.png)

**Output:**

```text
============================================================ 
 SVM (RBF) 
                  precision    recall  f1-score   support

        crazing     0.8333    1.0000    0.9091        45
      inclusion     0.9091    0.8889    0.8989        45
        patches     0.8462    0.7333    0.7857        45
 pitted_surface     0.7805    0.7111    0.7442        45
rolled-in_scale     0.9375    1.0000    0.9677        45
      scratches     0.9091    0.8889    0.8989        45

       accuracy                         0.8704       270
      macro avg     0.8693    0.8704    0.8674       270
   weighted avg     0.8693    0.8704    0.8674       270

============================================================ 
 Random Forest 
                  precision    recall  f1-score   support

        crazing     0.7759    1.0000    0.8738        45
      inclusion     0.7692    0.8889    0.8247        45
        patches     0.7333    0.4889    0.5867        45
 pitted_surface     0.6136    0.6000    0.6067        45
rolled-in_scale     0.8333    1.0000    0.9091        45
      scratches     0.9375    0.6667    0.7792        45

       accuracy                         0.7741       270
      macro avg     0.7771    0.7741    0.7634       270
   weighted avg     0.7771    0.7741    0.7634       270

============================================================ 
 k-NN (k=5) 
                  precision    recall  f1-score   support

        crazing     0.6809    0.7111    0.6957        45
      inclusion     0.6957    0.7111    0.7033        45
        patches     1.0000    0.0222    0.0435        45
 pitted_surface     0.3922    0.8889    0.5442        45
rolled-in_scale     0.8491    1.0000    0.9184        45
      scratches     1.0000    0.4667    0.6364        45

       accuracy                         0.6333       270
      macro avg     0.7696    0.6333    0.5902       270
   weighted avg     0.7696    0.6333    0.5902       270
```

## 5. Effect of HOG parameters (cell size × orientations)
Models are selected on the **validation** set; the test set stays untouched.

```python
grid_rows, feat_cache = [], {}
for cell in (4, 8, 16):
    for ori in (6, 9, 12):
        Fg = extract_hog(X_img, cell, ori); feat_cache[(cell, ori)] = Fg
        for name in ("SVM (RBF)", "Random Forest"):
            m = make_models()[name]
            t0 = time.time(); m.fit(Fg[tr_idx], y[tr_idx]); p = m.predict(Fg[va_idx])
            r = metrics(y[va_idx], p)
            grid_rows.append(dict(Cell=f"{cell}x{cell}", Orientations=ori, Classifier=name, Features=Fg.shape[1],
                                  Accuracy=r["Accuracy"], F1=r["F1"], Time_s=time.time() - t0))
            print(f"cell {cell:>2} ori {ori:>2} {name:<14} acc={r['Accuracy']:.4f} f1={r['F1']:.4f}")
grid_df = pd.DataFrame(grid_rows).round(4)
display(grid_df)
RESULTS["HOG parameter study (validation set)"] = grid_df
```

**Output:**

```text
cell  4 ori  6 SVM (RBF)      acc=0.8000 f1=0.7935
cell  4 ori  6 Random Forest  acc=0.6630 f1=0.6349
cell  4 ori  9 SVM (RBF)      acc=0.8074 f1=0.8025
cell  4 ori  9 Random Forest  acc=0.5778 f1=0.5498
cell  4 ori 12 SVM (RBF)      acc=0.8111 f1=0.8055
cell  4 ori 12 Random Forest  acc=0.6074 f1=0.5824
cell  8 ori  6 SVM (RBF)      acc=0.8704 f1=0.8679
cell  8 ori  6 Random Forest  acc=0.7889 f1=0.7812
cell  8 ori  9 SVM (RBF)      acc=0.8741 f1=0.8714
cell  8 ori  9 Random Forest  acc=0.7481 f1=0.7393
cell  8 ori 12 SVM (RBF)      acc=0.8889 f1=0.8876
cell  8 ori 12 Random Forest  acc=0.8074 f1=0.7994
cell 16 ori  6 SVM (RBF)      acc=0.9111 f1=0.9097
cell 16 ori  6 Random Forest  acc=0.9037 f1=0.9035
cell 16 ori  9 SVM (RBF)      acc=0.9148 f1=0.9131
cell 16 ori  9 Random Forest  acc=0.8926 f1=0.8908
cell 16 ori 12 SVM (RBF)      acc=0.9185 f1=0.9173
cell 16 ori 12 Random Forest  acc=0.8926 f1=0.8912
```

| Cell   |   Orientations | Classifier    |   Features |   Accuracy |     F1 |   Time_s |
|:-------|---------------:|:--------------|-----------:|-----------:|-------:|---------:|
| 4x4    |              6 | SVM (RBF)     |      23064 |     0.8    | 0.7935 |  64.4543 |
| 4x4    |              6 | Random Forest |      23064 |     0.663  | 0.6349 |  54.874  |
| 4x4    |              9 | SVM (RBF)     |      34596 |     0.8074 | 0.8025 | 109.447  |
| 4x4    |              9 | Random Forest |      34596 |     0.5778 | 0.5498 |  62.8383 |
| 4x4    |             12 | SVM (RBF)     |      46128 |     0.8111 | 0.8055 | 133.794  |
| 4x4    |             12 | Random Forest |      46128 |     0.6074 | 0.5824 |  58.5023 |
| 8x8    |              6 | SVM (RBF)     |       5400 |     0.8704 | 0.8679 |   6.9509 |
| 8x8    |              6 | Random Forest |       5400 |     0.7889 | 0.7812 |  28.9177 |
| 8x8    |              9 | SVM (RBF)     |       8100 |     0.8741 | 0.8714 |  12.9306 |
| 8x8    |              9 | Random Forest |       8100 |     0.7481 | 0.7393 |  35.8752 |
| 8x8    |             12 | SVM (RBF)     |      10800 |     0.8889 | 0.8876 |  21.837  |
| 8x8    |             12 | Random Forest |      10800 |     0.8074 | 0.7994 |  38.614  |
| 16x16  |              6 | SVM (RBF)     |       1176 |     0.9111 | 0.9097 |   0.7748 |
| 16x16  |              6 | Random Forest |       1176 |     0.9037 | 0.9035 |  13.7495 |
| 16x16  |              9 | SVM (RBF)     |       1764 |     0.9148 | 0.9131 |   1.7561 |
| 16x16  |              9 | Random Forest |       1764 |     0.8926 | 0.8908 |  17.842  |
| 16x16  |             12 | SVM (RBF)     |       2352 |     0.9185 | 0.9173 |   2.0838 |
| 16x16  |             12 | Random Forest |       2352 |     0.8926 | 0.8912 |  19.8186 |

```python
fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))
for ax, name in zip(axes, ("SVM (RBF)", "Random Forest")):
    pv = grid_df[grid_df.Classifier == name].pivot(index="Cell", columns="Orientations", values="F1")
    sns.heatmap(pv, annot=True, fmt=".3f", cmap="viridis", ax=ax); ax.set_title(f"{name}: validation F1")
plt.tight_layout(); plt.show()

best = grid_df[grid_df.Classifier == "SVM (RBF)"].sort_values("F1", ascending=False).iloc[0]
BEST_CELL, BEST_ORI = int(best.Cell.split("x")[0]), int(best.Orientations)
print(f"Best SVM config on validation -> cell {BEST_CELL}x{BEST_CELL}, orientations {BEST_ORI}, F1={best.F1}")
```

![figure 4](images/fig_04_cell15.png)

**Output:**

```text
Best SVM config on validation -> cell 16x16, orientations 12, F1=0.9173
```

## 6. Final models with the best HOG configuration (test set)

```python
F_best = feat_cache[(BEST_CELL, BEST_ORI)]
final = {}
final["SVM (RBF)"] = make_pipeline(StandardScaler(), SVC(kernel="rbf", C=10, gamma="scale", probability=True, random_state=SEED))
final["Random Forest"] = RandomForestClassifier(n_estimators=300, n_jobs=-1, random_state=SEED)
final_rows, final_preds = {}, {}
for name, m in final.items():
    m.fit(F_best[tr_idx], y[tr_idx]); p = m.predict(F_best[te_idx]); final_preds[name] = p
    final_rows[name] = metrics(y[te_idx], p)
final_df = pd.DataFrame(final_rows).T.round(4)
display(final_df)
RESULTS[f"Final test performance (cell {BEST_CELL}x{BEST_CELL}, {BEST_ORI} ori)"] = final_df

fig, axes = plt.subplots(1, 2, figsize=(13, 5))
for ax, (name, p) in zip(axes, final_preds.items()):
    sns.heatmap(confusion_matrix(y[te_idx], p), annot=True, fmt="d", cmap="Blues",
                xticklabels=classes, yticklabels=classes, ax=ax, cbar=False)
    ax.set_title(f"{name} - test confusion matrix"); ax.tick_params(axis="x", rotation=45)
plt.tight_layout(); plt.show()
print(classification_report(y[te_idx], final_preds["SVM (RBF)"], target_names=classes, digits=4))
```

|               |   Accuracy |   Precision |   Recall |     F1 |
|:--------------|-----------:|------------:|---------:|-------:|
| SVM (RBF)     |     0.9185 |      0.9183 |   0.9185 | 0.9181 |
| Random Forest |     0.8963 |      0.8968 |   0.8963 | 0.8943 |

![figure 5](images/fig_05_cell17.png)

**Output:**

```text
                 precision    recall  f1-score   support

        crazing     0.9362    0.9778    0.9565        45
      inclusion     0.9767    0.9333    0.9545        45
        patches     0.8000    0.8000    0.8000        45
 pitted_surface     0.8605    0.8222    0.8409        45
rolled-in_scale     1.0000    1.0000    1.0000        45
      scratches     0.9362    0.9778    0.9565        45

       accuracy                         0.9185       270
      macro avg     0.9183    0.9185    0.9181       270
   weighted avg     0.9183    0.9185    0.9181       270
```

## 7. Robustness analysis (brightness, Gaussian noise, blur, rotation)
Transforms are applied to the **test images only**; the trained models are not retrained.

```python
rng = np.random.default_rng(SEED)
def brightness(im, d):  return np.clip(im.astype(np.int16) + d, 0, 255).astype(np.uint8)
def noise(im, s):       return np.clip(im + rng.normal(0, s, im.shape), 0, 255).astype(np.uint8)
def blur(im, k):        return cv2.GaussianBlur(im, (k, k), 0)
def rotate(im, a):
    M = cv2.getRotationMatrix2D((IMG_SIZE / 2, IMG_SIZE / 2), a, 1.0)
    return cv2.warpAffine(im, M, (IMG_SIZE, IMG_SIZE), borderMode=cv2.BORDER_REFLECT)

conditions = {
    "Clean": lambda im: im,
    "Brightness +40": lambda im: brightness(im, 40), "Brightness -40": lambda im: brightness(im, -40),
    "Gaussian noise s=10": lambda im: noise(im, 10),  "Gaussian noise s=25": lambda im: noise(im, 25),
    "Blur k=5": lambda im: blur(im, 5),               "Blur k=9": lambda im: blur(im, 9),
    "Rotation 10 deg": lambda im: rotate(im, 10),     "Rotation 30 deg": lambda im: rotate(im, 30),
}
rob_rows = []
for cname, fn in conditions.items():
    Xt = np.array([fn(im) for im in X_img[te_idx]])
    Ft = extract_hog(Xt, BEST_CELL, BEST_ORI)
    for name, m in final.items():
        r = metrics(y[te_idx], m.predict(Ft))
        rob_rows.append(dict(Condition=cname, Classifier=name, Accuracy=r["Accuracy"], F1=r["F1"]))
rob = pd.DataFrame(rob_rows)
clean = rob[rob.Condition == "Clean"].set_index("Classifier")
rob["dAcc"] = rob.apply(lambda r: r.Accuracy - clean.loc[r.Classifier, "Accuracy"], axis=1)
rob["dF1"] = rob.apply(lambda r: r.F1 - clean.loc[r.Classifier, "F1"], axis=1)
rob = rob.round(4); display(rob)
RESULTS["Robustness analysis (test set)"] = rob

pv = rob.pivot(index="Condition", columns="Classifier", values="F1").loc[list(conditions)]
pv.plot(kind="bar", figsize=(11, 4.5)); plt.ylabel("Macro F1"); plt.title("Robustness: F1 under imaging conditions")
plt.xticks(rotation=40, ha="right"); plt.tight_layout(); plt.show()
```

| Condition           | Classifier    |   Accuracy |     F1 |    dAcc |     dF1 |
|:--------------------|:--------------|-----------:|-------:|--------:|--------:|
| Clean               | SVM (RBF)     |     0.9185 | 0.9181 |  0      |  0      |
| Clean               | Random Forest |     0.8963 | 0.8943 |  0      |  0      |
| Brightness +40      | SVM (RBF)     |     0.8111 | 0.8067 | -0.1074 | -0.1114 |
| Brightness +40      | Random Forest |     0.8222 | 0.8213 | -0.0741 | -0.0731 |
| Brightness -40      | SVM (RBF)     |     0.9037 | 0.9029 | -0.0148 | -0.0151 |
| Brightness -40      | Random Forest |     0.8963 | 0.8941 |  0      | -0.0002 |
| Gaussian noise s=10 | SVM (RBF)     |     0.3    | 0.2275 | -0.6185 | -0.6905 |
| Gaussian noise s=10 | Random Forest |     0.2481 | 0.1599 | -0.6481 | -0.7344 |
| Gaussian noise s=25 | SVM (RBF)     |     0.1963 | 0.1013 | -0.7222 | -0.8168 |
| Gaussian noise s=25 | Random Forest |     0.2    | 0.1026 | -0.6963 | -0.7917 |
| Blur k=5            | SVM (RBF)     |     0.4704 | 0.4386 | -0.4481 | -0.4795 |
| Blur k=5            | Random Forest |     0.5556 | 0.5174 | -0.3407 | -0.377  |
| Blur k=9            | SVM (RBF)     |     0.1741 | 0.0707 | -0.7444 | -0.8474 |
| Blur k=9            | Random Forest |     0.2074 | 0.128  | -0.6889 | -0.7663 |
| Rotation 10 deg     | SVM (RBF)     |     0.8963 | 0.8964 | -0.0222 | -0.0217 |
| Rotation 10 deg     | Random Forest |     0.9148 | 0.9145 |  0.0185 |  0.0202 |
| Rotation 30 deg     | SVM (RBF)     |     0.6222 | 0.5664 | -0.2963 | -0.3516 |
| Rotation 30 deg     | Random Forest |     0.7037 | 0.6909 | -0.1926 | -0.2034 |

![figure 6](images/fig_06_cell19.png)

## 8. Industrial quality-control decision module

```python
ACCEPTABLE_CLASSES = {"crazing"}      # EDIT: defect types tolerated by your (assumed) QC policy; all others -> REJECT
CONF_THRESHOLD = 0.50                 # below this the result is flagged for manual re-inspection
qc_model = final["SVM (RBF)"]

def inspect_product(image, true_label=None, show=True):
    im = load_gray(image) if isinstance(image, str) else image
    f = extract_hog([im], BEST_CELL, BEST_ORI)
    proba = qc_model.predict_proba(f)[0]
    k = int(np.argmax(proba)); cls = classes[k]; conf = proba[k] * 100
    defective = cls not in ACCEPTABLE_CLASSES
    print("PRODUCT INSPECTION RESULT")
    print(f"Prediction: {'DEFECTIVE' if defective else 'NON-DEFECTIVE'}  (type: {cls})")
    print(f"Confidence: {conf:.1f}%")
    print(f"Action: {'REJECT PRODUCT' if defective else 'ACCEPT PRODUCT'}")
    if conf / 100 < CONF_THRESHOLD: print("Note: low confidence -> recommend manual re-inspection")
    if true_label: print(f"(ground truth: {true_label})")
    if show:
        plt.figure(figsize=(3, 3)); plt.imshow(im, cmap="gray"); plt.axis("off"); plt.show()
    print("-" * 40)

for i in np.random.default_rng(1).choice(te_idx, 4, replace=False):
    inspect_product(X_img[i], true_label=classes[y[i]])
```

**Output:**

```text
PRODUCT INSPECTION RESULT
Prediction: NON-DEFECTIVE  (type: crazing)
Confidence: 99.6%
Action: ACCEPT PRODUCT
(ground truth: crazing)
```

![figure 7](images/fig_07_cell21.png)

**Output:**

```text
----------------------------------------
PRODUCT INSPECTION RESULT
Prediction: DEFECTIVE  (type: pitted_surface)
Confidence: 94.6%
Action: REJECT PRODUCT
(ground truth: pitted_surface)
```

![figure 8](images/fig_08_cell21.png)

**Output:**

```text
----------------------------------------
PRODUCT INSPECTION RESULT
Prediction: DEFECTIVE  (type: inclusion)
Confidence: 92.8%
Action: REJECT PRODUCT
(ground truth: inclusion)
```

![figure 9](images/fig_09_cell21.png)

**Output:**

```text
----------------------------------------
PRODUCT INSPECTION RESULT
Prediction: DEFECTIVE  (type: inclusion)
Confidence: 90.6%
Action: REJECT PRODUCT
(ground truth: inclusion)
```

![figure 10](images/fig_10_cell21.png)

**Output:**

```text
----------------------------------------
```

## 9. Save all results to `results.md` (send this file back for the report)

```python
lines = ["# Lab 05 Results", "",
         f"- Dataset: NEU Surface Defect Database, {len(df)} images, {len(classes)} classes ({', '.join(classes)})",
         f"- Image size: {IMG_SIZE}x{IMG_SIZE}, grayscale; split train/val/test = {len(tr_idx)}/{len(va_idx)}/{len(te_idx)}",
         f"- Best HOG config (validation, SVM): cell {BEST_CELL}x{BEST_CELL}, {BEST_ORI} orientations, 2x2 blocks, L2-Hys",
         f"- Acceptable classes in QC module: {sorted(ACCEPTABLE_CLASSES)}", ""]
for title, tab in RESULTS.items():
    lines += [f"## {title}", "", tab.to_markdown(), ""]
with open("results.md", "w") as fh: fh.write("\n".join(lines))
print(open("results.md").read()[:1500], "\n...\nSaved results.md")
try:
    from google.colab import files; files.download("results.md")
except Exception: pass
```

**Output:**

```text
# Lab 05 Results

- Dataset: NEU Surface Defect Database, 1800 images, 6 classes (crazing, inclusion, patches, pitted_surface, rolled-in_scale, scratches)
- Image size: 128x128, grayscale; split train/val/test = 1260/270/270
- Best HOG config (validation, SVM): cell 16x16, 12 orientations, 2x2 blocks, L2-Hys
- Acceptable classes in QC module: ['crazing']

## Class distribution

| label           |   images |
|:----------------|---------:|
| crazing         |      300 |
| inclusion       |      300 |
| patches         |      300 |
| pitted_surface  |      300 |
| rolled-in_scale |      300 |
| scratches       |      300 |

## Baseline classifier comparison (test set, cell 8x8, 9 ori)

|               |   Accuracy |   Precision |   Recall |     F1 |   Train+Pred time (s) |
|:--------------|-----------:|------------:|---------:|-------:|----------------------:|
| SVM (RBF)     |     0.8704 |      0.8693 |   0.8704 | 0.8674 |               13.1322 |
| Random Forest |     0.7741 |      0.7771 |   0.7741 | 0.7634 |               34.6474 |
| k-NN (k=5)    |     0.6333 |      0.7696 |   0.6333 | 0.5902 |                0.4799 |

## Classification report: SVM (test)

|                 |   precision |   recall |   f1-score |   support |
|:----------------|------------:|---------:|-----------:|----------:|
| crazing         |      0.8333 |   1      |     0.9091 |   45      |
| inclusion       |      0.9091 |   0.8889 |     0.8989 |   45      |
| patches         |      0.8462 |   0.7333  
...
Saved results.md
```

## 10. Bonus: real-time webcam / video prototype (run locally, not in Colab)
Press **q** to quit.

```python
def run_realtime(source=0):
    cap = cv2.VideoCapture(source)
    while cap.isOpened():
        ok, frame = cap.read()
        if not ok: break
        g = cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (IMG_SIZE, IMG_SIZE))
        proba = qc_model.predict_proba(extract_hog([g], BEST_CELL, BEST_ORI))[0]
        k = int(np.argmax(proba)); defective = classes[k] not in ACCEPTABLE_CLASSES
        txt = f"{'DEFECTIVE' if defective else 'PASS'} ({classes[k]}, {proba[k]*100:.0f}%)"
        cv2.putText(frame, txt, (10, 35), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255) if defective else (0, 200, 0), 2)
        cv2.imshow("HOG Inspection", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"): break
    cap.release(); cv2.destroyAllWindows()

# run_realtime(0)            # webcam
# run_realtime("video.mp4")  # or a video file
```
