# Skin Lesion Boundary Detection Using Canny Edge Detection

**Hanzala Ajaz — FA23-BAI-016**

This notebook (`CVLAB4_ASSIGNMENT_1.ipynb`) ran end-to-end in Google Colab with no errors.
This README documents what it does and the real results produced.

---

## What's inside

| Section | What it does |
|---|---|
| Setup | Self-installs packages, downloads HAM10000 via `kagglehub`, picks 1 representative image per class (5 images total) |
| Task 1-2 | Displays originals, converts to grayscale, applies Gaussian filtering |
| Task 3 | Canny edge detection at 3 threshold settings (50-100, 100-200, 150-250) per image |
| Task 4 | Auto-selects the best threshold per image (edge density closest to a 10% target) |
| Task 5 | Contour detection on the selected edge map, boundary drawn on the original |
| Task 6 | Area (`cv2.contourArea`) and perimeter (`cv2.arcLength`) measurement → Table 1 |
| Final Comparison | 8 filter × edge-detector combinations tested under real Gaussian noise → Table 2 |
| Report | Auto-generates `results_boundary/report.md` with both tables + all 6 questions answered |

## How to run
Colab → Runtime → GPU (not strictly required for this lab, but keeps it consistent with
Labs 01-03) → upload the notebook → Runtime → Run all. Packages and dataset download
themselves (Kaggle login prompt on first dataset download).

---

## Results (from this run)

### Threshold selection reasoning (Task 4)

| Image | Density @ 50-100 | Density @ 100-200 | Density @ 150-250 | Selected |
|---|---|---|---|---|
| Image 1 (melanoma) | 0.4% | 0.3% | 0.2% | 50-100 |
| Image 2 (melanocytic nevi) | 0.5% | 0.0% | 0.0% | 50-100 |
| Image 3 (basal cell carcinoma) | 6.2% | 1.8% | 0.5% | 50-100 |
| Image 4 (dermatofibroma) | 1.4% | 0.1% | 0.0% | 50-100 |
| Image 5 (vascular lesions) | 1.7% | 0.1% | 0.0% | 50-100 |

**50-100 was selected for all 5 images** — every image's edge density at every threshold
setting fell well below the 10% target (0.0%–6.2%, versus a 5–15% "well-balanced" band), so
the lowest threshold (which always produces the highest density among the three) ended up
closest in every case. This is a useful finding in itself: it suggests the 10% target was
calibrated for a noisier/higher-contrast image than these dermoscopic images actually are —
worth noting in your discussion, since it means the "auto-selection" didn't really have to
discriminate between genuinely competitive options here.

### Table 1 — Lesion Area and Perimeter

| Image | Best Filter | Edge Method | Area (pixels) | Perimeter (pixels) |
|---|---|---|---|---|
| Image 1 (melanoma) | Gaussian | Canny (50-100) | 1,031 | 125.4 |
| Image 2 (melanocytic nevi) | Gaussian | Canny (50-100) | 350 | 458.0 |
| Image 3 (basal cell carcinoma) | Gaussian | Canny (50-100) | 16,234 | 655.0 |
| Image 4 (dermatofibroma) | Gaussian | Canny (50-100) | 1,926 | 544.6 |
| Image 5 (vascular lesions) | Gaussian | Canny (50-100) | 7,740 | 355.0 |

**Note:** Image 2's perimeter (458.0) is large relative to its area (350) compared to the
other images — a high perimeter-to-area ratio like this usually signals a fragmented or
jagged contour rather than one clean lesion boundary, worth a visual sanity-check against the
Task 5 figure before reporting it as a clean measurement.

### Final Comparison — Filter × Edge Detector Robustness (under Gaussian noise)

| Method | Noise Handling | Edge Quality | Boundary Detection | Overall Performance |
|---|---|---|---|---|
| Original + Sobel | Good | Noisy | Clear single boundary | Good |
| Original + Canny | Poor | Noisy | Clear single boundary | Fair |
| Average + Sobel | Good | Noisy | Clear single boundary | Good |
| Average + Canny | Good | Sparse | Clear single boundary | Good |
| Gaussian + Sobel | Good | Noisy | Clear single boundary | Good |
| Gaussian + Canny | Good | Sparse | Fragmented / multiple contours | Fair |
| Median + Sobel | Good | Noisy | Clear single boundary | Good |
| Median + Canny | Good | Sparse | Clear single boundary | Good |

**Reading it:** Unfiltered Canny (Original + Canny) was the only combination with **Poor**
noise handling — exactly the behavior expected, since Canny's hysteresis thresholding gets
fooled by unfiltered noise, generating spurious strong edges. Once any of the three filters
(Average, Gaussian, or Median) is applied first, Canny's noise handling becomes Good. The one
outlier is **Gaussian + Canny**, which handled noise well but still fragmented into multiple
contours — on this sample, Median + Canny gave the cleanest overall result (Good across every
column) among the Canny variants.

---

## Output files (from `./results_boundary/` after running)

- `report.md` — full report with both tables and all 6 discussion questions answered
- `table1_area_perimeter.csv`, `table2_final_comparison.csv`
- `figures/` — originals, preprocessing grid, Canny threshold grid, full 5-step pipeline figure

## Key takeaways

1. **All 5 images converged on the same Canny threshold (50-100)** — their edge densities were all far below the 10% target, suggesting the target density may need recalibrating for low-contrast dermoscopic images, rather than this being a genuinely close call per image.
2. **Pre-filtering is what fixes Canny's noise sensitivity** — unfiltered Canny was the only "Poor" result in the whole comparison; any of the 3 filters brought it up to "Good".
3. **Median + Canny was the most consistently clean combination** overall, with no fragmentation and good noise handling.
4. Image 2's unusually high perimeter-to-area ratio is worth double-checking visually — it may indicate a fragmented boundary rather than a true measurement issue.
